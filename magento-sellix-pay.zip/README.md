magento2-sellix-pay
======================

Sellix Pay Magento2 extension

Install
=======

1. Upload code to folder app/code/Sellix/Pay

2.  Enter following commands to install module:
    php bin/magento setup:upgrade
    php bin/magento setup:static-content:deploy

4. Enable and configure Sellix Pay in Magento Admin under Stores -> Configuration-> Sales -> Payment Methods -> Sellix Pay
